<?php
use ArmoredCore\WebObjects\View;

class OperadorCheckinController extends BaseAuthController
{
    public function index(){
        $this->loginFilterbyRole('operadorcheckin');
        return view::make('operadorcheckin.index');
    }
}