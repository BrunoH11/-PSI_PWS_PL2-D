<?php
use ArmoredCore\WebObjects\View;
use ArmoredCore\Controllers\BaseController;

class CheckinAppController extends BaseController
{
    public function index(){
        $this->loginFilterbyRole('operadorcheckin');
        $flights = Flight::all();

        return view::make('operadorcheckin.index', ['flights'=>$flights]);
    }
}