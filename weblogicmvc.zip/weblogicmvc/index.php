<?php
/**
 * Created by PhpStorm.
 * User: smendes
 * Date: 09-05-2016
 * Time: 11:17
 */

// @ Import server.rules
// Goto request.server.mod {0/0}